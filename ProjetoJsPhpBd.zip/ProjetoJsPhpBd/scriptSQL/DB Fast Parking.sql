create database dbFastParking;

show databases;

use dbFastParking;


ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password
BY 'bcd127';  

show tables;

insert into tblVeiculos(nomeCliente, Descricao, placa)
values ('roberto', 'savero', 'ACB-1577');

select * from tblVeiculos;
select * from tblPrecos;

create table tblPrecos(
	idPreco int not null auto_increment primary key,
    PrimeiroPreco numeric,
    DemaisPrecos numeric
);

insert into tblPrecos(PrimeiroPreco, DemaisPrecos)
value("10","2");

create table tblReservas(
	idReserva int not null auto_increment primary key,
    idPreco int(8) not null,
    idVeiculo int(8) not null,
    
    constraint FK_Reserva_Veiculos
    foreign key (idVeiculo)
    references tblVeiculos(idVeiculo),
    
    constraint FK_Reserva_preco
    foreign key (idPreco)
    references tblPrecos(idPreco)
);

show tables;

select * from tblReservas;

create table tblVeiculos(
	idVeiculo int not null auto_increment primary key,
    nomeCliente varchar(50) not null,
    Descricao varchar(30) not null,
    placa varchar(10) not null,
    idPreco int(8) not null,
    entrada timestamp not null default current_timestamp,
    saida timestamp,
    
    constraint FK_veiculos_preco
    foreign key (idPreco)
    references tblPrecos(idPreco)
);

insert into tblVeiculos (nomeCliente, Descricao, placa, idPreco)
values ('Michel Araujo de Souza','Corsa Preto','GMS-6281',1);

select * from tblVeiculos;


select * from tblVeiculos where tblVeiculos.idVeiculo = 4 order by tblVeiculos.nomeCliente asc;

update tblVeiculos set saida = current_timestamp() where idVeiculo = 1;


