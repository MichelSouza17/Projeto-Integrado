<?php 
// Importe do arquivo para iniciar as dependencias da API
require_once ("vendor/autoload.php");

//instancia da classe App
$app = new \Slim\App();

//EndPoint para o acesso a raíz da pasta da API
$app->get('/', function($request, $response, $args){
    return $response->getBody()->write('API Fast Parking');    
}); 

////EndPoint para o acesso a todos os dados de contatos da API
$app->get('/entrada', function($request, $response, $args){
    
    //Import do arquivo que vai buscar no BD
    require_once('../bd/apiEntrada.php');
    
    // Recebendo dados da QueryString(Essas váriaveis podem ou não chegar na requisição)
    //Existem duas maneiras de receber uma variavl prla QueryStrin
        //$-GET
        //getQueryParamns()
        
    if(isset($request->getQueryParams()['nome']))
    {   
                                       //Aqui colocamos a variavel que ser enviada na requisição
        $nome = $request->getQueryParams()['nome']; 
        $listVeiculos = buscarVeiculos($nome);
    }
    else
    {
        //função para listar todos os Contatos
        $listVeiculos = listarVeiculos(0);
    }
    
    //Valida se houve retorno de dados do banco
    if($listVeiculos)    
        return $response    -> withStatus(200)
                            ->withHeader('Content-Type', 'application/json')
                            ->write($listVeiculos);
    else
        return $response    ->withStatus(204);
});

////EndPoint para buscar pelo id
$app->get('/entrada/{id}', function($request, $response, $args){
  
    $id = $args['id'];
    
   //import do arquivo que vai buscar no banco
    require_once('../bd/apiEntrada.php');
    
    //Função para Listar todos os contatos
    $listVeiculos = listarVeiculos($id);    
    
    //Valida se houve retorno de dados do banco
    
    if($listVeiculos)    
        return $response    -> withStatus(200)
                            ->withHeader('Content-Type', 'application/json')
                            ->write($listVeiculos);
    else
        return $response    ->withStatus(204);
});

//EndPoint para receber os dados via POST
$app->post('/entrada', function($request, $response, $args){
    
    //Recebe o ContetType da requisição
    $contentType = $request->getHeaderLine('Content-Type');
    
    //Valida apenas o tipo de Content Type que esta chegando
    if($contentType == 'application/json')
    {
        //Recebe todos os dados enviados para a API no formato JSON
        $dadosJSON = $request->getParsedBody(); 
        
        //Valida se os dados recebidos estão nulos
        if($dadosJSON == "" || $dadosJSON == null)
        {
            return $response ->withStatus (400)
                             ->withHeader('Content-Type', 'application/json')
                             ->write('
                                    {
                                        "status": "Fail",
                                        "message": "Dados enviados não podem ser nulos"
                                    }
                                ');
        }
        else
        {
            //import do arquivo que vai buscar no banco
            require_once('../bd/apiEntrada.php');
            
            //Valida se os dados foram inseridos corretamente no BD
            $retornoDados = inserirVeiculo($dadosJSON);
            
            if($retornoDados)
                return $response ->withStatus (201)
                                 ->withHeader('Content-Type', 'application/json')
                                 ->write($retornoDados);
            else
                return $response ->withStatus (400)
                                 ->withHeader('Content-Type', 'application/json')
                                 ->write('
                                    {
                                        "status": "Fail",
                                        "message": "Falha ao inserir os dados no BD.
                                        Verificar se os dados enviados estã corretos."
                                    }
                                ');
        }
    }
    else
    {
        //Retorna Erro de Content Type
        return $response ->withStatus (400)
                         ->withHeader('Content-Type', 'application/json')
                         ->write('
                                    {
                                        "status": "Fail",
                                        "message": "Erro no Content Type da Requisição"
                                    }
                                ');
    }
});

$app->delete('/entrada/{id}', function($request, $response, $args){
    
    $id = $args['id'];
    
    //import do arquivo que vai buscar no banco
    require_once('../bd/apiEntrada.php');
    
    //Função para excluir os contatos
    $deleteVeiculos = excluirVeiculo($id);
    
    if($deleteVeiculos)
        return $response    ->withStatus(200)
                            ->withHeader('Content-Type', 'application/json')
                            ->write($deleteVeiculos);
    else
        return $response    ->withStatus(204);
    
});

$app->put('/entrada/{id}', function($request, $response, $args){
    
    $id = $args['id'];
     
   $contentType = $request->getHeaderLine('Content-type', 'application/json');
    

    if($contentType == 'application/json'){
        
       $dadosJSON = $request->getParsedBody();

            if($dadosJSON == "" || $dadosJSON == null){
                
                return $response    ->withStatus(400)
                                    ->withHeader('Content-type', 'application/json')
                                    ->write('
                                    
                                        {
                                        
                                        "status":"Fail",
                                        "message":"Não é possível fazer a atualização com dados nulos!"
                                        
                                        }
                                            ');
            }

            
    }
    
    
    require_once('../bd/apiEntrada.php');
    
    $retornoDados = editarVeiculo($id, @$dadosJSON);
    
    if($retornoDados){
        
        return $response    ->withStatus(200)
                            ->withHeader('Content-type', 'application/json')
                            ->write('
                            
                                    {
                                    
                                    "status":"Sucess",
                                    "message":"O veiculo Saiu!"
                                    
                                    }
                            
                                    ');
    } 
                    
     
    else{
        
        return $response    ->withStatus(400)
                            ->withHeader('Content-type', 'application/json')
                            ->write('   
                            
                                    {
                                    
                                    "status":"Fail",
                                    "message":"Contato inexistente."
                                    
                                    }
                            
                                    ');
    }
    
   });
//Executa todos os EndPoints criados na API
$app->run();

?>