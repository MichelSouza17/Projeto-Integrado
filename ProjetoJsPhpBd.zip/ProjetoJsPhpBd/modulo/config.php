<?php 
/****************************************************************************************
    Objetivo: Arquivo para criar variaveis ou constantes que serão utilizados no projeto
    Data: 11/12/2020
    Auto: Michel e Luiz
*****************************************************************************************/


/*CONSTANTES*/

const ERRO_CONEX_BD_MYSQL = "ERRO: Não foi possivel estabelecer a conexão com o Banco de Dados MySQl, Verificar os dados de conexão com o BD.";

?>