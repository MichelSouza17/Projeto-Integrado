<?php

function listarVeiculos($id)
{
    
    /*Abre a conexão com o BD*/

    //Import do arquivo de Variaveis e Constantes
    require_once('../modulo/config.php');

    //Import do arquivo de função para conectar no BD
    require_once('conexaoMysql.php');
    
    //chama a função que vai estabelecer a conexão com o BD
    if(!$conex = conexaoMysql())
    {
        echo("<script> alert('".ERRO_CONEX_BD_MYSQL."'); </script>");
        //die; //Finaliza a interpretação da página
    }
    
        $sql = "select *
                from tblVeiculos
                ";
    
        //Validação para filtrar pelo ID
        if($id > 0)
            $sql = $sql . " where tblVeiculos.idVeiculo =".$id;
    
    
        $sql = $sql . " order by tblVeiculos.nomeCliente asc";
    
        $select = mysqli_query($conex, $sql);    
        
  
        while($rsVeiculos = mysqli_fetch_assoc($select))
        {
            $dados[] = array (  
                
                "idVeiculo"      => $rsVeiculos['idVeiculo'],
                "nomeCliente"    => $rsVeiculos['nomeCliente'],
                "placa"          => $rsVeiculos['placa'],
                "Descricao"      => $rsVeiculos['Descricao'],
                "entrada"        => $rsVeiculos['entrada'],
                "saida"          => $rsVeiculos['saida']
                
            );            
              
        } 
    
    if(isset($dados))    
            $listVeiculosJSON = convertJSON($dados); 
    else
        return false;
                      
    
    //Verifica se foi gerado um arquivo JSON
    if(isset($listVeiculosJSON))
        return $listVeiculosJSON;
    else
        return false;   
}

function buscarVeiculos($nome)
{    
    /*Abre a conexão com o BD*/

    //Import do arquivo de Variaveis e Constantes
    require_once('../modulo/config.php');

    //Import do arquivo de função para conectar no BD
    require_once('conexaoMysql.php');
    
    //chama a função que vai estabelecer a conexão com o BD
    if(!$conex = conexaoMysql())
    {
        echo("<script> alert('".ERRO_CONEX_BD_MYSQL."'); </script>");
        //die; //Finaliza a interpretação da página
    }
    
        $sql = "select tblVeiculos.*
                from tblVeiculos
                 where tblVeiculos.idVeiculo and tblVeiculos.nomeCliente like '%".$nome."%'
                ";
    
        $select = mysqli_query($conex, $sql);    
        
    
        while($rsVeiculos = mysqli_fetch_assoc($select))
        {
            $dados[] = array (  
                
                "idVeiculo"      => $rsVeiculos['idVeiculo'],
                "nomeCliente"    => $rsVeiculos['nomeCliente'],
                "placa"          => $rsVeiculos['placa'],
                "Descricao"      => $rsVeiculos['Descricao']
                
            );            
              
        } 
    
    if(isset($dados))    
            $listVeiculosJSON = convertJSON($dados); 
    else
        return false;
                      
    
    //Verifica se foi gerado um arquivo JSON
    if(isset($listVeiculosJSON))
        return $listVeiculosJSON;
    else
        return false;   
}

function inserirVeiculo($dadosCliente)
{
    /*Abre a conexão com o BD*/

    //Import do arquivo de Variaveis e Constantes
    require_once('../modulo/config.php');

    //Import do arquivo de função para conectar no BD
    require_once('conexaoMysql.php');

    //chama a função que vai estabelecer a conexão com o BD
    if(!$conex = conexaoMysql())
    {
        echo("<script> alert('".ERRO_CONEX_BD_MYSQL."'); </script>");
        //die; //Finaliza a interpretação da página
    }

        /*Variaveis*/
        $nome = (string) null;
        $placa = (string) null;
        $Descricao = (string) null;
        $idPreco = (int) null;
    
        //Converte o formato JSON para um Array de dados
        //$dadosContato = convertArray($dados);

        /*Recebe todos os dados do formulário*/
        $nome = $dadosCliente['nomeCliente'];
        $placa = $dadosCliente['placa'];
        $Descricao = $dadosCliente['Descricao'];
        $idPreco = 1;
       
        $sql = "insert into tblVeiculos 
                    (
                        nomeCliente, 
                        placa,
                        Descricao,
                        idPreco
                    )
                    values
                    (
                        '". $nome ."',
                        '". $placa ."',
                        '". $Descricao ."',
                        ". $idPreco ."
                    )
                ";



        //Executa no BD o Script SQL
    
        if (mysqli_query($conex, $sql))
        {
            $dados = convertJSON($dadosCliente);
            return $dados;
        }
        else
            return false;
}

//Exclui o contato 
function excluirVeiculo($excluirVeiculo)
{
    //Import do arquivo de Variaveis e Constantes
    require_once('../modulo/config.php');

    //Import do arquivo de função para conectar no BD
    require_once('conexaoMysql.php');

    //chama a função que vai estabelecer a conexão com o BD
    if(!$conex = conexaoMysql())
    {
        echo("<script> alert('".ERRO_CONEX_BD_MYSQL."'); </script>");
        //die; //Finaliza a interpretação da página
    }

    //Recebendo o id para a exclusão
    //$excluir = $excluirContato['id'];

    $sql = "delete from tblVeiculos
            where idVeiculo = " . $excluirVeiculo;

    //Executa no BD o Script SQL

    if (mysqli_query($conex, $sql))
    {
        //Apagando a imagem da pasta arquivos, após o registro ter sido excluido do BD

        //Recebendo o nome da foto que será excluida da pasta
        //$nomeFoto = $_GET['foto'];

        //Validação para não apagar o arquivo padrão semFoto.png
       // if($nomeFoto != "semFoto.png")
            //Apaga a foto da pasta arquivos
           // unlink('../arquivos/'.$nomeFoto);


       return true;
    }
    else
       return false;

    
}

function editarVeiculo($id, $dadosCliente)
{
    /*Abre a conexão com o BD*/

    //Import do arquivo de Variaveis e Constantes
    require_once('../modulo/config.php');

    //Import do arquivo de função para conectar no BD
    require_once('conexaoMysql.php');

    //chama a função que vai estabelecer a conexão com o BD
    if(!$conex = conexaoMysql())
    {
        echo("<script> alert('".ERRO_CONEX_BD_MYSQL."'); </script>");
        //die; //Finaliza a interpretação da página
    }
    

        $sql = "update tblVeiculos set 
        
                saida = current_timestamp() 
                where idVeiculo= ".$id;

    
        //Executa no BD o Script SQL

        if (mysqli_query($conex, $sql))
                if(mysqli_affected_rows($conex) > 0)
                return true;
            else
                return false;

}

//fubnverte um Array em JSON
function convertJSON($objeto)
    {
        //forçamos o cabeçalho do arquivo a ser aplicação do tipo JSON
        header("content-tipe:application/json");
            
        //json_encode converte o array de dados em JSON
        $listJSON = json_encode($objeto); 
        
        return $listJSON;
        
    }
 
//fubnverte um JSON em Array
function convertArray($objeto)
    {
            
        //json_encode converte JSON em Array
        $listArray = json_encode($objeto); 
        
        return $listArray;
        
    }

?>
